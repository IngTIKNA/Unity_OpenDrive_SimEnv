using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyRoads3Dv3;
//___________________________
using System.Xml;
using System.IO;
using System;   

public class XODR2PATH : MonoBehaviour{

	public ERRoadNetwork roadNetwork;
    public enum PathType : ushort{
    None = 0,
    Line = 1,
    Arc = 2,
    Spiral = 3
    }
    void Start()
    {
        //_______________________________________________//
        roadNetwork = new ERRoadNetwork();               //
        ERRoadType roadType = new ERRoadType();          //
        //_______________________________________________//
        //____________________________________________________________________________________________//
		roadType.roadWidth = 4.0f;                                                                //  Road Width
		roadType.roadMaterial = Resources.Load("Materials/roads/road material") as Material;      //  Road Material -> Marking Type etc.
        roadType.layer = 1;                                                                       //  
        roadType.tag = "Untagged";                                                                //
        //____________________________________________________________________________________________//
        //______________________________________________//
        //______________________________________________//
        var LineRoads = new List<ERRoad>();             //   The container individually keeps road components
        var linePaths = new List<LinePath>();           //   The container individually keeps road components with the line geometry
        //______________________________________________//
        var ArcRoads  = new List<ERRoad>();             //   The container individually keeps road components
        var arcPaths  = new List<ARCPath>();            //   The container individually keeps road components with the arc geometry
        //______________________________________________//
        //______________________________________________//


        PathType pathType;    
        XmlNodeList geoList = parseFile();
        double tmp;


        for(int i=0; i< geoList.Count; i++){
            var gotFirst = false;
            UInt16 counter = 0;
            foreach(XmlNode child in geoList[i].ChildNodes)
            {
                if(child.Name == "line")
                {   
                    //_______________________________________________________________________________________________________________________________
                    XmlElement geoA = (System.Xml.XmlElement)geoList[i];
                    var x_Value = geoA.GetAttribute("x");
                    double.TryParse( x_Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float xVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________
                    var y_Value = geoA.GetAttribute("y");
                    double.TryParse( y_Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float yVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________
                    var heading = geoA.GetAttribute("hdg");
                    double.TryParse( heading, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float hdgVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________
                    var length  = geoA.GetAttribute("length");
                    double.TryParse( length, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float lenVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________
                    pathType = PathType.Line;
                    linePaths.Add(new LinePath( linePaths.Count, xVal, yVal, lenVal, hdgVal));  
                    LineRoads.Add(new ERRoad());
                    LineRoads[linePaths.Count-1] = roadNetwork.CreateRoad("line"+ (linePaths.Count-1).ToString(), roadType, linePaths[linePaths.Count-1].markers);                
                
                }else if(child.Name == "arc"){                                   //
                    XmlElement geoA = (System.Xml.XmlElement)geoList[i];
                    //_______________________________________________________________________________________________________________________________//
                    var x_Value = geoA.GetAttribute("x");
                    double.TryParse( x_Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float xVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________//
                    var y_Value = geoA.GetAttribute("y");
                    double.TryParse( y_Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float yVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________//
                    var heading = geoA.GetAttribute("hdg");
                    double.TryParse( heading, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float hdgVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________//
                    var length  = geoA.GetAttribute("length");
                    double.TryParse( length, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float lenVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________//
                    var child_curvature = child.Attributes["curvature"];
                    double.TryParse( child_curvature.Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tmp);
                    float curveVal = Convert.ToSingle(tmp);
                    //_______________________________________________________________________________________________________________________________//
                    //______________________________________________________________________//
                    pathType = PathType.Arc;
                    arcPaths.Add(new ARCPath( arcPaths.Count , xVal , yVal , lenVal, hdgVal, curveVal));
                    ArcRoads.Add(new ERRoad());
                    ArcRoads[arcPaths.Count-1] = roadNetwork.CreateRoad("arc"+ (arcPaths.Count-1).ToString(), roadType, arcPaths[arcPaths.Count-1].markers);
                }else if(child.Name == "spiral"){
                    Debug.Log("Child Node Name ==> spiral"  + i.ToString());
                    pathType = PathType.Spiral;
                }         
            }
        }

    }


    public XmlNodeList parseFile()
    {
    //____________________________________________________________
        XmlDocument doc = new XmlDocument();
        doc.Load("Town01.xml");
    //____________________________________________________________
        XmlNodeList elemList = doc.GetElementsByTagName("road");        //Element("OpenDRIVE").Elements("road");
        //Debug.Log("1-");
        //Debug.Log("Number of planView      => " + elemList.Count);
    //____________________________________________________________
        XmlNodeList geoList = doc.GetElementsByTagName("geometry");        //Element("OpenDRIVE").Elements("road");
        //Debug.Log("2-");
        //Debug.Log("Num of geometry tags" + geoList.Count);
    //____________________________________________________________
        //XmlNodeList plan = doc.GetElementsByTagName("planView");        //Element("OpenDRIVE").Elements("road"); 
        //Debug.Log("************** Count" + plan.Count.ToString());

        return geoList;
    }
}



public abstract class paths{// : MonoBehaviour{

    public float xStart;
    public float yStart;
    public int pathIndex;
    public abstract void createPath(); 

}

//_____________________________________________________________________________________________________________________________________________________________________
//____________________________________________________________________________ LINE GEOMETRY __________________________________________________________________________
//____________________________________________________________  _______________________________________________________________________________________________________
public class LinePath : paths{

    public float xEnd;
    public float yEnd;
    public float angle;
    public float length;
    //______________________________________
    public Vector3[] markers  = new Vector3[2];
    public LinePath(int road_index , float x_Start, float y_Start, float length, float hdg){
        //_________________________________//
        this.xStart    = x_Start;          //
        this.yStart    = y_Start;          //
        this.angle     = hdg;              //
        this.length    = length;           //
        this.pathIndex = road_index;       //
        //_________________________________//
        //________________________________________________________________________________________________//                                                               //
        this.markers[0]  = new Vector3(this.xStart,  0,  this.yStart);                                    //
        this.xEnd = this.xStart + Convert.ToSingle(Math.Cos(this.angle)) * this.length;                   //
        this.yEnd = this.yStart + Convert.ToSingle(Math.Sin(this.angle)) * this.length;                   //
        this.markers[1]  = new Vector3(this.xEnd,  0,   this.yEnd);	                                      //
        //________________________________________________________________________________________________// 
    }

    public override void createPath(){

    }

}
//_____________________________________________________________________________________________________________________________________________________________________
//_____________________________________________________________________________________________________________________________________________________________________
//_____________________________________________________________________________________________________________________________________________________________________




//_____________________________________________________________________________________________________________________________________________________________________
//____________________________________________________________________________ ARC GEOMETRY ___________________________________________________________________________
//_____________________________________________________________________________________________________________________________________________________________________
public class ARCPath : paths{

    public float xCentral;
    public float xEnd;
    public float xTemp;

    public float yCentral;
    public float yEnd;
    public float yTemp;
    public float angle;
    public float length;
    public float radius;
    public float centralAngle;
    public int arrSize;
    public int sign;
    public Vector3[] markers;

    //______________________________________
    //public Vector3[] markers;

    public ARCPath(int road_index ,float x_Start, float y_Start, float length, float hdg, float curvature){
        this.xStart       = x_Start;
        this.yStart       = y_Start;
        this.length       = length;
        this.pathIndex    = road_index;
        this.radius       = (Math.Abs(1 / curvature));
        this.centralAngle = this.length / this.radius;   
        //______________________________________________________________________________//
        //____________________________ NUMBER OF ONCREMENTS ____________________________//
        this.arrSize =  Mathf.FloorToInt(this.length / 0.5f) + 2;                       // must be at least 2 
        //______________________________________________________________________________//
        this.sign      =  Math.Sign(curvature);                                         //
        //_________________________________________________________________________________________________//
        this.markers = new Vector3[this.arrSize];                                                          //
        //_________________________________________________________________________________________________//
        
        //_________________________________________________________________________________________________//
        //_________________________________ CENTRAL POINT _________________________________________________//
        this.xCentral = this.xStart + Convert.ToSingle( Math.Cos(hdg + (Math.PI / 2) * this.sign * (-1) - Math.PI)) * this.radius;   
        this.yCentral = this.yStart + Convert.ToSingle( Math.Sin(hdg + (Math.PI / 2) * this.sign * (-1) - Math.PI)) * this.radius;        
        //______________________________________________________________________________________________________________________________________________________________________//   
        //______________________________________________________________________________________________________________________________________________________________________//   
        this.xEnd = this.xCentral + Convert.ToSingle( Math.Cos( (hdg + (this.centralAngle) * this.sign)  - (Math.PI / 2) * this.sign ) ) * this.radius;     //
        this.yEnd = this.yCentral + Convert.ToSingle( Math.Sin( (hdg + (this.centralAngle) * this.sign)  - (Math.PI / 2) * this.sign ) ) * this.radius;     //
        //______________________________________________________________________________________________________________________________________________________________________//
        this.markers[this.arrSize-1] = new Vector3(this.xEnd, 0f, this.yEnd);                                                                                                   //  END
        this.markers[0]  = new Vector3((this.xStart), 0,  (this.yStart));                                                                                                       //  START
        //______________________________________________________________________________________________________________________________________________________________________//
        //______________________________________________________________________________________________________________________________________________________________________//
        //___________________________________________________________ POINT BETWEEN START and END POINTS ___________________________________________________________________________________________________//
        //__________________________________________________________________________________________________________________________________________________________________________________________________//
        for(int i =1; i<(this.arrSize-1); i++){                                                                                                                                                             //
            this.xTemp = this.xCentral + Convert.ToSingle( Math.Cos( (hdg + ((i) * (this.centralAngle/(this.arrSize-1))) * this.sign)  - (Math.PI / 2) * this.sign )) * this.radius;                        // TODO => sign of cuvature   
            this.yTemp = this.yCentral + Convert.ToSingle( Math.Sin( (hdg + ((i) * (this.centralAngle/(this.arrSize-1))) * this.sign)  - (Math.PI / 2) * this.sign )) * this.radius;                        // TODO => sign of cuvature       
            this.markers[i]  = new Vector3(this.xTemp,  0,   this.yTemp);	                                                                                                                                //
        }                                                                                                                                                                                                   //
        //__________________________________________________________________________________________________________________________________________________________________________________________________//
        //__________________________________________________________________________________________________________________________________________________________________________________________________//
    }

    public override void createPath(){
    }

}
//_____________________________________________________________________________________________________________________________________________________________________
//_____________________________________________________________________________________________________________________________________________________________________
//_____________________________________________________________________________________________________________________________________________________________________
